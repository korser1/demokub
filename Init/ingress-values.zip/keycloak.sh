#!/bin/sh

cd keycloak

./keycloak.sh

cd ..
